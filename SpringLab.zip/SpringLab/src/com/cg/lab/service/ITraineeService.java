package com.cg.lab.service;

import java.util.List;

import com.cg.lab.dto.Trainee;




public interface ITraineeService {
	public int addTraineeData(Trainee train);
	public List<Trainee> showAllTrainees();
	public void deleteTrainee(int tRaineeId);
	public List<Trainee> showTrainee(int tRaineeId);
	public Trainee updateTrainee(Trainee train);
}
