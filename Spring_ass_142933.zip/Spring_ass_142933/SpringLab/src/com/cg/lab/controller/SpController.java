package com.cg.lab.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.lab.dto.Trainee;
import com.cg.lab.service.ITraineeService;

@Controller
public class SpController {
	@Autowired
	ITraineeService traineeservice;
	@RequestMapping(value="all",method=RequestMethod.GET)
public String getAll()
{
	return "login";
	
}
	@RequestMapping(value="operation",method=RequestMethod.POST)
	public String getoperation()
	{
		return "home";
		
	}

	@RequestMapping(value="add",method=RequestMethod.GET)
	public String adddetails(@ModelAttribute("my") Trainee train,Map<String,Object> model)
	{
		System.out.println("*****");
		List<String> myDeg=new ArrayList<>();
		myDeg.add("JEE");
		myDeg.add("VNV");
		myDeg.add("Oracle");
		model.put("deg", myDeg);
		return "addform";
		
	}
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@Valid@ModelAttribute("my") Trainee train,BindingResult result,Map<String,Object> model)
	{
		
		int id=0;
		if(result.hasErrors())
		{
			
			List<String> myDeg=new ArrayList<>();
			myDeg.add("JEE");
			myDeg.add("VNV");
			myDeg.add("Oracle");
			model.put("deg", myDeg);
			
			return new ModelAndView("addform");
		}
		else
		{
		
		 id=traineeservice.addTraineeData(train);
		}
		return new ModelAndView("success","edata",id);
		
	}
	@RequestMapping(value="retrieve",method=RequestMethod.GET)
	public ModelAndView showAllTrainees()
	{
		List<Trainee> myAllData=traineeservice.showAllTrainees();
		return new ModelAndView("showall","temp",myAllData);
	}
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteTrainees()
	{
		return "deletetraineefirst";
	}
	@RequestMapping(value="dodeletesecond",method=RequestMethod.GET)
	public ModelAndView TraineeShowDelete(@RequestParam("tid") int id)
	{
		//System.out.println("id is .."+id);
		List<Trainee> mysingleData=traineeservice.showTrainee(id);
		return new ModelAndView("deletetrainee","temp1",mysingleData);
	}
	
	
	@RequestMapping(value="successdelete",method=RequestMethod.GET)
	public String TraineeDelete(@RequestParam("iiid") int id1)
	{
		System.out.println("id is .."+id1);
		
		traineeservice.deleteTrainee(id1);
		return "successdeleted";
	}
	@RequestMapping(value="modify",method=RequestMethod.GET)
	public String modifyData()
	{
		return "modifyform";
	}
	
	@RequestMapping(value="updatetrainee",method=RequestMethod.GET)
	public ModelAndView TraineeShowModify(@RequestParam("myid") int myid,@ModelAttribute("my")Trainee train)
	{
		System.out.println("id is .."+myid);
		List<Trainee> mymodifyData=traineeservice.showTrainee(myid);
		return new ModelAndView("modifyform","temp2",mymodifyData);
	}
	
	@RequestMapping(value="update",method=RequestMethod.POST)
	public String TraineeUpdatePage(@ModelAttribute("my")Trainee train)
	{
System.out.println("hiii");
traineeservice.updateTrainee(train);
		
		return "successupdated";
	}
}
