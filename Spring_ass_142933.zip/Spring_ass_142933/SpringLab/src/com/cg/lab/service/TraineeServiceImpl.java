package com.cg.lab.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.lab.dao.ITraineeDao;
import com.cg.lab.dto.Trainee;

@Service("trainingservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService{
	@Autowired
	ITraineeDao traineedao;

	@Override
	public int addTraineeData(Trainee train) {
		// TODO Auto-generated method stub
		return traineedao.addTraineeData(train);
	}

	@Override
	public List<Trainee> showAllTrainees() {
		// TODO Auto-generated method stub
		return traineedao.showAllTrainees();
	}

	@Override
	public void deleteTrainee(int tRaineeId) {
		// TODO Auto-generated method stub
		 traineedao.deleteTrainee(tRaineeId);
	}

	@Override
	public List<Trainee> showTrainee(int tRaineeId) {
		// TODO Auto-generated method stub
		return traineedao.showTrainee(tRaineeId);
	}

	@Override
	public Trainee updateTrainee(Trainee train) {
		// TODO Auto-generated method stub
		return traineedao.updateTrainee(train);
	}

}
