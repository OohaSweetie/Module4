package com.cg.lab.dao;

import java.util.List;

import com.cg.lab.dto.Trainee;


public interface ITraineeDao {
	public int addTraineeData(Trainee train);
	public List<Trainee> showAllTrainees();
	public void deleteTrainee(int tRaineeId);
	public Trainee updateTrainee(Trainee train);
	public List<Trainee> showTrainee(int tRaineeId);
}
