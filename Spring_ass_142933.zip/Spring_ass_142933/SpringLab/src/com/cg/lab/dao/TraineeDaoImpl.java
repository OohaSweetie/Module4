package com.cg.lab.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.lab.dto.Trainee;

@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao {
	@PersistenceContext
    EntityManager entitymanager;
	@Override
	public int addTraineeData(Trainee train) {
		// TODO Auto-generated method stub
		entitymanager.persist(train);
		entitymanager.flush();
		return train.gettRaineeId();
	}
	@Override
	public List<Trainee> showAllTrainees() {
		// TODO Auto-generated method stub
		Query queryOne=entitymanager.createQuery("FROM Trainee");
		List<Trainee> myList=queryOne.getResultList();
		return myList;
	}
	@Override
	public void deleteTrainee(int tRaineeId) {
		// TODO Auto-generated method stub
		Query queryTwo=entitymanager.createQuery("DELETE FROM Trainee WHERE tRaineeId=:tid");
		queryTwo.setParameter("tid", tRaineeId);
		queryTwo.executeUpdate();
	}
	@Override
	public List<Trainee> showTrainee(int tRaineeId) {
		// TODO Auto-generated method stub
		Query queryOne=entitymanager.createQuery("SELECT t FROM Trainee t WHERE tRaineeId=:tid1");
		queryOne.setParameter("tid1", tRaineeId);
		List<Trainee> myList=queryOne.getResultList();
		return myList;
	}
	@Override
	public Trainee updateTrainee(Trainee train) {
		// TODO Auto-geTrainee train;
		
		entitymanager.merge(train);
		return train;
	}

}
