package com.cg.lab.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Traineedetails")
public class Trainee {
	@Id
	@Column(name="traineeId")
int tRaineeId;
	@Column(name="traineeName")
String tRaineeName;
	@Column(name="traineeDomain")
String tRaineeDomain;
	@Column(name="traineeLocation")
String lOcation;
public int gettRaineeId() {
	return tRaineeId;
}
public void settRaineeId(int tRaineeId) {
	this.tRaineeId = tRaineeId;
}
public String gettRaineeName() {
	return tRaineeName;
}
public void settRaineeName(String tRaineeName) {
	this.tRaineeName = tRaineeName;
}
public String gettRaineeDomain() {
	return tRaineeDomain;
}
public void settRaineeDomain(String tRaineeDomain) {
	this.tRaineeDomain = tRaineeDomain;
}
public String getlOcation() {
	return lOcation;
}
public void setlOcation(String lOcation) {
	this.lOcation = lOcation;
}

}
