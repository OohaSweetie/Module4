package com.cg.springlab.dto;

public class Employee implements EmployeeDetail{
     int empId;
     String empName;
     double empsal;
     String empBU;
     int age;
     
	public Employee() {
	
	}

	

	public Employee(int empId, String empName, double empsal, String empBU,
			int age) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empsal = empsal;
		this.empBU = empBU;
		this.age = age;
	}



	@Override
	public void getAllEmployeeDetail() 
	{
		System.out.println("Employee Details");
		System.out.println("--------------------");
		System.out.println("Employee ID :"+empId);
		System.out.println("Employee Name :"+empName);
		System.out.println("Employee Salary :"+empsal);
		System.out.println("Employee BU :"+empBU);
		System.out.println("Employee Age :"+age);
	}

}
