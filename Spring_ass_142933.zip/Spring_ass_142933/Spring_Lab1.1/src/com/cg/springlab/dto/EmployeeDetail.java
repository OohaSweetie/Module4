package com.cg.springlab.dto;

public interface EmployeeDetail {
       public void getAllEmployeeDetail();
}
