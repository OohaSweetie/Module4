package com.cg.author.service;

import com.cg.author.entitites.Author;

public interface AuthorService {
	public abstract Author findAuthorById(int id);

	public abstract void addAuthor(Author author);

	public abstract void removeAuthor(Author author);

	public abstract void updateAuthor(Author author);

}
