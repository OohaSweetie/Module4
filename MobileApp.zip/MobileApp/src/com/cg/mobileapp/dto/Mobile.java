package com.cg.mobileapp.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="mobile")
public class Mobile {
	@Id
	@Column(name="mob_id")
private int mobId;
	@Column(name="mob_name")
private String mobName;
	@Column(name="mob_category")
private String mobCategory;
	@Column(name="mob_price")
private int mobPrice;
	@Column(name="mob_type")
private String mobType;
public int getMobId() {
	return mobId;
}
public void setMobId(int mobId) {
	this.mobId = mobId;
}
public String getMobName() {
	return mobName;
}
public void setMobName(String mobName) {
	this.mobName = mobName;
}
public String getMobCategory() {
	return mobCategory;
}
public void setMobCategory(String mobCategory) {
	this.mobCategory = mobCategory;
}
public int getMobPrice() {
	return mobPrice;
}
public void setMobPrice(int mobPrice) {
	this.mobPrice = mobPrice;
}
public String getMobType() {
	return mobType;
}
public void setMobType(String mobType) {
	this.mobType = mobType;
}

}
