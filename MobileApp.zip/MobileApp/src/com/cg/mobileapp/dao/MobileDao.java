package com.cg.mobileapp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.mobileapp.dto.Mobile;

@Repository("mobiledao")
public class MobileDao implements IMobileDao {
	@PersistenceContext
    EntityManager entitymanager;
	@Override
	public void addMobileData(Mobile mob) {
		// TODO Auto-generated method stub
		entitymanager.persist(mob);
		entitymanager.flush();
	}
	@Override
	public List<Mobile> showAllMobiles() {
		// TODO Auto-generated method stub
		Query queryOne=entitymanager.createQuery("FROM Mobile");
		List<Mobile> myList=queryOne.getResultList();
		return myList;
	}
	@Override
	public void updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		Query queryTwo=entitymanager.createQuery("DELETE FROM Mobile WHERE mobId=:id");
		queryTwo.setParameter("id", mobId);
		queryTwo.executeUpdate();
		
	}

}
