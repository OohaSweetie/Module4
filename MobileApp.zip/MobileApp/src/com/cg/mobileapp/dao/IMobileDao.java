package com.cg.mobileapp.dao;

import java.util.List;

import com.cg.mobileapp.dto.Mobile;



public interface IMobileDao {
	public void addMobileData(Mobile mob);
	public List<Mobile> showAllMobiles();
	public void updateMobile(Mobile mob);
	public void deleteMobile(int mobId);
}
