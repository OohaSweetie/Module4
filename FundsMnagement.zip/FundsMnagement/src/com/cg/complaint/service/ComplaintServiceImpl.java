package com.cg.complaint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.complaint.bean.ComplaintBean;
import com.cg.complaint.dao.IComplaintDAO;
import com.cg.complaint.exception.ComplaintException;



@Service
public class ComplaintServiceImpl implements IComplaintService {
	
	@Autowired
	IComplaintDAO complaintDao;
	
	@Override
	public int addComplaintDetails(ComplaintBean bean) throws ComplaintException 
	{
		String category=bean.getCategory();
		System.out.println(category);
		bean.setStatus("Open");
			if(category.equals("Internet Banking"))
			{
				bean.setPriority("High");
			}
			else if(category.equals("General Banking")){
				bean.setPriority("Medium");
			}
			else
			{
				bean.setPriority("Low");

			}
		return complaintDao.addComplaintDetails(bean);
	}

	@Override
	public ComplaintBean checkStatus(int complaintId) throws ComplaintException 
	{
		
		return complaintDao.checkStatus(complaintId);
	}

}
