package com.cg.complaint.service;

import com.cg.complaint.bean.ComplaintBean;
import com.cg.complaint.exception.ComplaintException;



public interface IComplaintService 
{
	public int addComplaintDetails(ComplaintBean bean) throws ComplaintException;
	public ComplaintBean checkStatus(int complaintId) throws ComplaintException;
}
