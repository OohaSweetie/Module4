package com.cg.complaint.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.complaint.bean.ComplaintBean;
import com.cg.complaint.exception.ComplaintException;
import com.cg.complaint.service.IComplaintService;





@Controller
public class ComplaintController 
{
	
	@Autowired
	private IComplaintService complaintService;
	
	@RequestMapping("/showHome")
	public String showHomePage()
	{
		return("index");
	}
	
	@RequestMapping("/addComplaint")
	public String complaintForm(Model model)
	{
		
		return("addcomplaint");
	}
	
	@RequestMapping(value="SubmitComplaint", method=RequestMethod.POST)
	public ModelAndView addTrain(@ModelAttribute("complaint") ComplaintBean bean,
			BindingResult result)
	{
		ModelAndView mv = new ModelAndView();
		
		if(result.hasErrors())
		{
			mv.setViewName("error");
			mv.addObject("message", "Binding Failed");
		}
		else
		{
			try
			{
				int id = complaintService.addComplaintDetails(bean);
				mv.setViewName("success");
				mv.addObject("id", id);
				mv.addObject("complaint", bean);
			} 
			catch(ComplaintException e) 
			{
				mv.setViewName("error");
				mv.addObject("message", e.getMessage());
			}
		}
		
		return mv;
	}
	
	@RequestMapping("checkstatus")
	public String traineeForm(Model model)
	{
		
		return("check");
	}
	
	@RequestMapping(value="getDetail",method=RequestMethod.POST)
	public ModelAndView getDetail(@ModelAttribute("complaint") ComplaintBean bean, @RequestParam("complaintId") int complaintId) throws Exception
	{
		
		ModelAndView mv = new ModelAndView();
		try {
			bean = complaintService.checkStatus(complaintId);
			System.out.println("in search: "+bean);
			mv.addObject("complaint", bean);
			mv.addObject("message", "Deleted");
			mv.setViewName("check");
		} catch (Exception e) {
			mv.addObject("message", e.getMessage());
			mv.setViewName("error");
		}
		
		return mv;
	}
}
