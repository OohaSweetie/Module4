package com.cg.complaint.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="complaint_tbl")
public class ComplaintBean {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Id_generator")
	@SequenceGenerator(name="Id_generator", sequenceName = "hibernate_sequence", allocationSize=10)
	@Column(name="complaintId")
	private int complaintId;
	@Column(name="accountId")
	private int accountId;
	@Column(name="branchCode", length=30)
	private String branchCode;
	@Column(name="emailId", length=30)
	private String emailId;
	@Column(name="category", length=30)
	private String category;
	@Column(name="description", length=30)
	private String description;
	@Column(name="priority", length=30)
	private String priority;
	@Column(name="status", length=30)
	private String status;
	
	public ComplaintBean() {
		super();
	}
	public ComplaintBean(int complaintId, int accountId, String branchCode,
			String emailId, String category, String description,
			String priority, String status) {
		super();
		this.complaintId = complaintId;
		this.accountId = accountId;
		this.branchCode = branchCode;
		this.emailId = emailId;
		this.category = category;
		this.description = description;
		this.priority = priority;
		this.status = status;
	}
	public int getComplaintId() {
		return complaintId;
	}
	public void setComplaintId(int complaintId) {
		this.complaintId = complaintId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
