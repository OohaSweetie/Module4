package com.cg.complaint.dao;

import java.util.List;

import com.cg.complaint.bean.ComplaintBean;
import com.cg.complaint.exception.ComplaintException;

public interface IComplaintDAO {

	public int addComplaintDetails(ComplaintBean bean) throws ComplaintException;
	
	public ComplaintBean checkStatus(int complaintId) throws ComplaintException;
}
