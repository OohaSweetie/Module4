package com.cg.complaint.exception;

public class ComplaintException extends Exception 
{

	private static final long serialVersionUID = 1051358854739950261L;

	public ComplaintException()
	{
		super();
		
	}

	public ComplaintException(String arg0)
	{
		super(arg0);
		
	}
	
	

}
