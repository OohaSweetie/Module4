/*The implementation of the DAO interface to provide the implementation details*/
package com.cg.sky.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sky.dao.ISkyDAO;
import com.cg.sky.dto.Sky;


@Service
@Transactional
public class SkyServiceImpl implements ISkyService {
	@Autowired
	private ISkyDAO skyDAO;

	@Override
	public List<Sky> getAllData() {
		
		return skyDAO.getAllData();
	}

	@Override
	public Sky getServiceDetail(String customerNumber) {
		
		return skyDAO.getServiceDetail(customerNumber);
	}


}
