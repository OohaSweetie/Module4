/*The interface of service which will have to call the dao class for better modularity.
 * It consists of various definitions of the functions which are present in the module
 * */
package com.cg.sky.service;

import java.util.List;

import com.cg.sky.dto.Sky;


public interface ISkyService {
	public List<Sky> getAllData();
	public Sky getServiceDetail(String customerNumber);
	
}
