/*The interface of DAO to define various methods*/
package com.cg.sky.dao;

import java.util.List;

import com.cg.sky.dto.Sky;



public interface ISkyDAO {
public List<Sky> getAllData();
public Sky getServiceDetail(String customerNumber);
}
