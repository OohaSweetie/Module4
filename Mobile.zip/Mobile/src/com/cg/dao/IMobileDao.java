package com.cg.dao;

import java.util.List;

import com.cg.dto.Mobile;




public interface IMobileDao {
	
	public int addMobile(Mobile mob);
	
	public void deleteMobile(int mobId);
	
	public List<Mobile> showAllMobile();
	
	public List<Mobile> searchMobile(int id);
	
	public void updateMobile(Mobile mob);

}
