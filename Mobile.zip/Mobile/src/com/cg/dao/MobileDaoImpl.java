package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dto.Mobile;


@Repository("mobiledao")
public class MobileDaoImpl implements IMobileDao{

	
	@PersistenceContext
	EntityManager entitymanager;
	@Override
	public int addMobile(Mobile mob) {
		
		entitymanager.persist(mob);
		entitymanager.flush();
		return mob.getMobId();
	}
	@Override
	public void deleteMobile(int mobId) {
		// TODO Auto-generated method stub
		Query queryTwo=entitymanager.createQuery("DELETE FROM Mobile where mobId=:mid");
		queryTwo.setParameter("mid", mobId);
		queryTwo.executeUpdate();
		
	}
	@Override
	public List<Mobile> showAllMobile() {
		Query queryOne=entitymanager.createQuery("FROM Mobile");
		List<Mobile> myList= queryOne.getResultList();
		return myList;
	}
	@Override
	public List<Mobile> searchMobile(int id) {
		Query querythree=entitymanager.createQuery("SELECT m FROM Mobile m where mobId=:tid");
		querythree.setParameter("tid", id);
		return querythree.getResultList();
	}
	@Override
	public void updateMobile(Mobile mob) {
		// TODO Auto-generated method stub
		
		entitymanager.merge(mob);
		
	}

}
