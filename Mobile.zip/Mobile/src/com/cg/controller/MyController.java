package com.cg.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.dto.Mobile;

import com.cg.service.IMobileService;





@Controller
public class MyController {
	@Autowired
	IMobileService mobileservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll()
	{
		//System.out.println("xxxxx");
		return "home";
	}
	
	@RequestMapping(value="add",method=RequestMethod.GET)
	public String addEmployee(@ModelAttribute("my") Mobile mob,Map<String, Object>model)
	{
		List<String> myDesig= new ArrayList<>();
		myDesig.add("sam");
		myDesig.add("iphone");
		myDesig.add("moto");
		model.put("deg",myDesig);
		return "addmobile";
	}
	
	@RequestMapping(value="insertdata",method=RequestMethod.POST)
	public ModelAndView insertEmployee(@Valid @ModelAttribute("my") Mobile mob,BindingResult result,Map<String, Object>model)
	{
		int id=0;
		if(result.hasErrors())
		{
			List<String> myDesig= new ArrayList<>();
			myDesig.add("software engg");
			myDesig.add("Senr consult");
			myDesig.add("manager");
			model.put("deg",myDesig);
			return new ModelAndView("addmobile");
		}
		else
		{
		 id=mobileservice.addMobile(mob);
		}
		System.out.println("Name is "+mob.getMobName());
		return new ModelAndView("success", "mdata", id);
	}
	
	@RequestMapping(value="delete",method=RequestMethod.GET)
	public String deleteMobile()
	{
		return "deletemobile";
	}
	
	@RequestMapping(value="dodelete",method=RequestMethod.GET)
	public String employeeDelete(@RequestParam("mid") int id)
	{
		mobileservice.deleteMobile(id);
		System.out.println("Id is "+id);
		return "success";
	}
	
	@RequestMapping(value="show",method=RequestMethod.GET)
	public ModelAndView showAllEmployee()
	{
		
		List<Mobile> myAllData=mobileservice.showAllMobile();
		return new ModelAndView("showall", "temp", myAllData);
	}

	
	@RequestMapping(value="search",method=RequestMethod.GET)
	public String traineerRetrieve()
	{
		//System.out.println("xxxx");
		return "searchmobile";
	}
	
	@RequestMapping(value="searchinfo",method=RequestMethod.GET)
	public ModelAndView traineerRetrieve(@RequestParam("mid") int id)
	{
		
		List<Mobile> myAllData=mobileservice.searchMobile(id);
		//System.out.println("Id is "+id);
		//traineeservice.deleteTrainee(id);
		System.out.println("xxxx");
		return new ModelAndView("searched", "temp", myAllData);
	}
	
	@RequestMapping(value="x",method=RequestMethod.GET)
	public String traineerRetrievee()
	{
		//System.out.println("xxxx");
		return "home";
	}
	
	@RequestMapping(value="update",method=RequestMethod.GET)
	public String update()
	{
		//System.out.println("xxxxx");
		return "updatesearch";
	}
	
	@RequestMapping(value="update1",method=RequestMethod.GET)
	public ModelAndView updatee(@RequestParam("mid") int id)
	{
		
		List<Mobile> myAllData=mobileservice.searchMobile(id);
		//System.out.println("Id is "+id);
		//traineeservice.deleteTrainee(id);
		//System.out.println("xxxx");
		//System.out.println("123456789");
		return new ModelAndView("x", "temp", myAllData);
		
	}
	
	@RequestMapping(value="update2",method=RequestMethod.POST)
	public ModelAndView showupdate(@ModelAttribute("my") Mobile mob)
	{
		System.out.println("123456789");
		//traineeservice.upadate(trn);
		return new ModelAndView("y");
		//return new Mo
	}
	
	@RequestMapping(value="update3",method=RequestMethod.POST)
	public ModelAndView updateTrr(@ModelAttribute("my") Mobile mob)
	{
		System.out.println("123456789");
		mobileservice.updateMobile(mob);
		return new ModelAndView("s");
		//return new Mo
	}
}
