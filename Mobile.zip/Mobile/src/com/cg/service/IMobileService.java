package com.cg.service;

import java.util.List;

import com.cg.dto.Mobile;

public interface IMobileService {
	
	public int addMobile(Mobile mob);
	
	public void deleteMobile(int mobId);
	
	public List<Mobile> showAllMobile();
	
	public List<Mobile> searchMobile(int id);
	
	public void updateMobile(Mobile mob);

}
