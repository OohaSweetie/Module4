package com.cg.gear.dao;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;




public interface IGearDao {
	public Gear view(int queryId)throws GearException;
	
	public boolean update(Gear gear)throws GearException; 
}
