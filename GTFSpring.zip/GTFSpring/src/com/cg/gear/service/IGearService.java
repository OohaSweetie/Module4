package com.cg.gear.service;

import com.cg.gear.dto.Gear;
import com.cg.gear.exception.GearException;



public interface IGearService {
	public Gear view(int queryId)throws GearException;
	
	public boolean update(Gear gear)throws GearException; 
}
