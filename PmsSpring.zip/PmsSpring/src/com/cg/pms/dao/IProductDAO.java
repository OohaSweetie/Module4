package com.cg.pms.dao;

import java.util.List;

import com.cg.pms.dto.Product;
import com.cg.pms.exception.ProductException;



public interface IProductDAO 
{
	public int addProductDetails(Product product) throws ProductException;
	
	public Product getProduct(int id ) throws ProductException;
	
	public void updateProduct( Product product ) throws ProductException;
	
	public Product removeProduct( Product product ) throws ProductException;
	
	public List<Product> getAllProducts() throws ProductException;
}
