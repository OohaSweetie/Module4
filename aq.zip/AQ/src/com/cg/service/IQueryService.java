package com.cg.service;

import org.hibernate.QueryException;

import com.cg.bean.QueryMaster;

public interface IQueryService {
	public int addSolution(QueryMaster queryBean)throws QueryException; 
	public QueryMaster viewQuery(int queryId)throws QueryException;

}
