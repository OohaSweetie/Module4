package com.cg.service;

import org.hibernate.QueryException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.QueryMaster;
import com.cg.dao.IQueryDao;
@Service
public class QueryServiceImpl implements IQueryService{

	@Autowired
	IQueryDao queryDao;
	@Override
	public int addSolution(QueryMaster queryBean) throws QueryException {
	
		return queryDao.addSolution(queryBean);
	}
	@Override
	public QueryMaster viewQuery(int queryId) throws QueryException {
		
		return queryDao.viewQuery(queryId);
	}

}
