 package com.cg.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="query_master")
public class QueryMaster {

	@Id
	@Column(name="query_id")
	private int queryId;
	@Column(name="technology",length=30)
	
	private String technology;
	@Column(name="query_raised_by",length=20)
	
	private String queryRaisedBy;
	@Column(name="query",length=1000)
	
	private String query;
	@Column(name="solutions",length=1000)
	@NotEmpty(message="Solution field should not kept Blank")
	private String solutions;
	@Column(name="solution_given_by",length=20)
	@NotEmpty(message="You must select one of the name")
	private String solutionGivenBy;
	public int getQueryId() {
		return queryId;
	}
	public void setQueryId(int queryId) {
		this.queryId = queryId;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}
	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	public String getSolutionGivenBy() {
		return solutionGivenBy;
	}
	public void setSolutionGivenBy(String solutionGivenBy) {
		this.solutionGivenBy = solutionGivenBy;
	}
	public QueryMaster(int queryId, String technology, String queryRaisedBy,
			String query, String solutions, String solutionGivenBy) {
		super();
		this.queryId = queryId;
		this.technology = technology;
		this.queryRaisedBy = queryRaisedBy;
		this.query = query;
		this.solutions = solutions;
		this.solutionGivenBy = solutionGivenBy;
	}
	public QueryMaster() {
		super();
	}
	
}
