package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.hibernate.QueryException;
import org.springframework.stereotype.Repository;

import com.cg.bean.QueryMaster;

@Repository
@Transactional
public class QueryDaoImpl implements IQueryDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public int addSolution(QueryMaster queryBean) throws QueryException {
		
		QueryMaster bean=new QueryMaster();
		
		try{
			bean=entityManager.find(QueryMaster.class, queryBean.getQueryId());
			bean.setSolutions(queryBean.getSolutions());
			bean.setSolutionGivenBy(queryBean.getSolutionGivenBy());
			entityManager.merge(bean);
			
		}catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return bean.getQueryId();
	}

	@Override
	public QueryMaster viewQuery(int queryId) throws QueryException {
		QueryMaster bean=new QueryMaster();
		
		try {
			bean=entityManager.find(QueryMaster.class, queryId);
		} catch (Exception e) {
			throw new QueryException(e.getMessage());
		}
		return bean;
	}

}
