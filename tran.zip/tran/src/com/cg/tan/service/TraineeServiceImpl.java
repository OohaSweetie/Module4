package com.cg.tan.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.tran.dao.TraineeDao;
import com.cg.tran.entities.Trainee;
@Service
@Transactional
public class TraineeServiceImpl implements TraineeService {
@Autowired
TraineeDao dao;
	public int addTraineeDetails(Trainee trainee) {
		
		return dao.addTraineeDetails(trainee);
	}
	@Override
	public void updateTraineeDetails(Trainee trainee) {
		// TODO Auto-generated method stub
		dao.updateTraineeDetails(trainee);
	}
	@Override
	public ArrayList<Trainee> viewTraineeList() {
		// TODO Auto-generated method stub
		return dao.viewTraineeList();
	}
	@Override
	public int deleteTraineeDetails(Trainee trainee) {
		// TODO Auto-generated method stub
		return dao.deleteTraineeDetails(trainee);
	}
	@Override
	public Trainee retrieveSingleRecord(Trainee trainee) {
		// TODO Auto-generated method stub
		return dao.retrieveSingleRecord(trainee);
	}

}
