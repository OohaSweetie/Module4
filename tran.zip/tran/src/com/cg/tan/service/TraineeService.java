package com.cg.tan.service;
import java.util.ArrayList;
import com.cg.tran.entities.Trainee;

public interface TraineeService {
public int addTraineeDetails(Trainee trainee);
public ArrayList<Trainee> viewTraineeList();
public void updateTraineeDetails(Trainee trainee);
public int deleteTraineeDetails(Trainee trainee);
public Trainee retrieveSingleRecord(Trainee trainee);
//public Trainee getTraineeDetails(int id);
}
