package com.cg.tran.dao;

import java.util.ArrayList;

import com.cg.tran.entities.Trainee;

public interface TraineeDao {
	public int addTraineeDetails(Trainee trainee);
	public ArrayList<Trainee> viewTraineeList();
	public void updateTraineeDetails(Trainee trainee);
	public int deleteTraineeDetails(Trainee trainee);
	public Trainee retrieveSingleRecord(Trainee trainee);
	//public Trainee getTraineeDetails(int id);
}
