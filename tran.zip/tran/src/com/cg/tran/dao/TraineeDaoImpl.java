package com.cg.tran.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.tran.entities.Trainee;
@Repository
public class TraineeDaoImpl implements TraineeDao {
@PersistenceContext
EntityManager entityManager;
	@Override
	public int addTraineeDetails(Trainee trainee) {
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee.getTraineeId();
	}
	@Override
	public void updateTraineeDetails(Trainee trainee) {
		entityManager.merge(trainee);
		entityManager.flush();
		
	}
	@Override
	public ArrayList<Trainee> viewTraineeList() {
		ArrayList<Trainee> list;
		String query= "select t from Trainee t ";
		TypedQuery<Trainee> qry=entityManager.createQuery(query,Trainee.class);
		list=(ArrayList<Trainee>) qry.getResultList();
		return list;
	}
	@Override
	public int deleteTraineeDetails(Trainee trainee) {
		Trainee traine=entityManager.find(Trainee.class,trainee.getTraineeId());
		if(traine!=null){
		entityManager.remove(traine);
		entityManager.flush();
		return 1;
		}
		else
			
		return 0;
	}
	@Override
	public Trainee retrieveSingleRecord(Trainee trainee) {
		Trainee record=entityManager.find(Trainee.class,trainee.getTraineeId());
		return record;
	}
	

}
