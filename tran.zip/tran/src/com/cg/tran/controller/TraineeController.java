package com.cg.tran.controller;



import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.tan.service.TraineeService;
import com.cg.tran.entities.Login;
import com.cg.tran.entities.Trainee;

@Controller
public class TraineeController {
@Autowired
TraineeService service;
@RequestMapping("/LoginPage")
public String LoginPage(Model model)
{
	Login log=new Login();
	model.addAttribute("l",log);
	
	return "login";
}
@RequestMapping(value="/EnterLoginPage",method=RequestMethod.POST)
public String Enterloginpage(@ModelAttribute("l")Login bean,Model model){
	if(bean.getUsername().equals("capgemini")&& bean.getPassword().equals("corp@123"))
	{
		model.addAttribute("message","Login Successful");
	return "success";
	}
	else
		model.addAttribute("message","Invalid UserName or Password");
	return "error";
}
@RequestMapping("/addtrainee")
public String addTrainee(Model model)
{
	Trainee trainee=new Trainee();
	model.addAttribute("add",trainee);
	return "Add";
}
@RequestMapping("/EnterAddPage")
public String EnterAddPage(@ModelAttribute("add")Trainee bean,Model model){
	int id=service.addTraineeDetails(bean);
	model.addAttribute("traineeId",id);
	return "sucessful";
	
}
@RequestMapping("/retrievetrainee")
public String showTraineeRecord(Model model)
{
	Trainee trainee=new Trainee();
	model.addAttribute("single",trainee);
	return "viewSingleRecord";
}
@RequestMapping("EnterSingleRecord")
public String enterSinglerecord(@ModelAttribute("single")Trainee trainee,Model model){
	Trainee record=service.retrieveSingleRecord(trainee);
	model.addAttribute("singleList",record);
	return "singleRecord";
}
@RequestMapping("/retrieveall")
public String displayTraineeList(Model model){
	ArrayList<Trainee> list= service.viewTraineeList();
	model.addAttribute("TraineeList",list);
	return "ViewTrainee";
}
@RequestMapping("/deletetrainee")
public String deleteTrainee(Model model)
{
	Trainee  t= new Trainee();
	model.addAttribute("id",t);
	return "delete";


}
@RequestMapping("/deletetrainee1")
public String deleteTraineeDetails(@ModelAttribute("id")Trainee bean,Model model){
	int traineeId=service.deleteTraineeDetails(bean);
	model.addAttribute("TraineeId",bean);
	if(traineeId==1)
	{
		return "ViewTrainee";
	
	}
	else
	{
		return "error";
	}
}
@RequestMapping("/modifytrainee")
public String updateTraineeDetails(Model model)
{
	Trainee trainee=new Trainee();
	model.addAttribute("modify",trainee);
	return "UpdateTrainee";
}

@RequestMapping("/EnterUpdatePage")
public String updateTraineeDetails1(@ModelAttribute("modify")Trainee trainee,Model model)
{
	//Trainee modified=service.updateTraineeDetails(trainee);
	Trainee modified =service.retrieveSingleRecord(trainee);
	model.addAttribute("TraineeList",modified);
	return "Viewmodify";
}
@RequestMapping("/sucessfulmodify")
public String updateindb(@ModelAttribute("TraineeList")Trainee trainee1,Model model)
{
	service.updateTraineeDetails(trainee1);
	return "success";
	
}
}



