package com.cg.exception;

public class ShareException extends Exception {

	private static final long serialVersionUID = 2429005644596060387L;

	public ShareException() {
		super();
		
	}

	public ShareException(String arg0) {
		super(arg0);

	}
	
	

}
