package com.cg.spring.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.Trainee;

@Repository
public class TraineeDaoImpl implements TraineeDao {
	@PersistenceContext
	EntityManager em;

	@Override
	public int addTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		em.persist(trainee);
		em.flush();
		return trainee.gettId();
	}

	@Override
	public int deleteTraine(Trainee id) {
		// TODO Auto-generated method stub
		Trainee trainne = em.find(Trainee.class, id.gettId());
		if(trainne != null)
		em.remove(trainne);
		else
			return 0;
		return 1;
		//em.flush();
	}

	@Override
	public Trainee fetchRecord(Trainee id) {
		// TODO Auto-generated method stub
		Trainee trainee = em.find(Trainee.class, id.gettId());
		return trainee;
	
	}

	@Override
	public void updateRecord(Trainee record) {
		// TODO Auto-generated method stub
		em.merge(record);
		em.flush();
	}

	@Override
	public Trainee singleRecord(Trainee id) {
		// TODO Auto-generated method stub
		Trainee single = em.find(Trainee.class, id.gettId());
		return single;
	}

	@Override
	public ArrayList<Trainee> showAll() {
		// TODO Auto-generated method stub
		ArrayList<Trainee> list;
		String query = "select t from Trainee t";
		TypedQuery<Trainee> qry = em.createQuery(query,Trainee.class);
		list=(ArrayList<Trainee>) qry.getResultList();
		return list;
	}

}
