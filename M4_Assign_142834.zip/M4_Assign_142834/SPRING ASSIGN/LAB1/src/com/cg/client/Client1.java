package com.cg.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.cg.pojo.Employee;
import com.igate.Employee1;
import com.igate.SBU;

public class Client1 {

	public static void main(String[] args) {
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("BeanConfig2.xml"));
		Employee1 e=(Employee1) factory.getBean("Employee1");
	/*	SBU sbu=e.getSbu();
		System.out.println("Employee Details....");
		System.out.println("Employee Id:"+e.getEmployeeId());
		System.out.println("Employee Name:"+e.getEmployeeName());
		System.out.println("Employee Salary: "+e.getSalary());
		System.out.println("Employee age:"+e.getAge());
		System.out.println("Employee BusinessUnit:"+e.getBusinessUnit());
		System.out.println("SBU head:"+sbu.getSbuHead());
		System.out.println("SBU id:"+sbu.getSbuId());
		System.out.println("SBU name:"+sbu.getSbuName());*/
		System.out.println(e);
		
	}

}
