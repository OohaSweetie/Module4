package com.cg.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.cg.pojo.Employee;

public class Client {

	public static void main(String[] args) {
		BeanFactory factory=new XmlBeanFactory(new ClassPathResource("BeanConfig.xml"));
		Employee e=(Employee) factory.getBean("Employee");
		System.out.println("Employee Details....");
		System.out.println("Employee Id:"+e.getEmployeeId());
		System.out.println("Employee Name:"+e.getEmployeeName());
		System.out.println("Employee Salary: "+e.getSalary());
		System.out.println("Employee age:"+e.getAge());
		System.out.println("Employee BusinessUnit:"+e.getBusinessUnit());

	}

}
