package com.cg.soap.webservice;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;

import com.cg.soap.webservice.dao.ProductDAO;

public class ProductClient {

	public static void main(String[] args) throws MalformedURLException {
		// TODO Auto-generated method stub
		URL url=new URL("http://localhost:9977/ps?wsdl");
		QName qname=new QName("http://dao.webservice.soap.cg.com/","ProductDAOImplService");
		Service service=Service.create(url,qname);
		ProductDAO endPointIntfProxy=service.getPort(ProductDAO.class);
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter the name of product to find price");
		String name=scanner.next();
		int i=endPointIntfProxy.getProductPrice(name);
		if(i==-1)
			System.out.println("Product doesn't exist");
		else
			System.out.println("Price of Product  "+i);

	}

}
