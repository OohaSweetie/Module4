package com.cg.soap.webservice;

import javax.xml.ws.Endpoint;

import com.cg.soap.webservice.dao.ProductDAOImpl;

public class ProductPublisher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Endpoint.publish("http://127.0.0.1:9977/ps",new ProductDAOImpl());
		System.out.println("The service has been published"
				+"now we can check at http://localhost:9977/ps?wsdl");


	}

}
