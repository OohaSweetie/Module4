package com.cg.product.service;

import java.util.List;

import com.cg.product.beans.Product;

public interface ProductService {
	public List<Product> getProducts();
	public Product addProduct(Product product);


}
