package com.cg.product.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.cg.product.beans.Product;
import com.cg.product.staticdb.ProductDB;

public class ProductsDAOImpl implements ProductsDAO{
	static HashMap<Integer, Product> productMap = ProductDB.getProducts();

	@Override
	public List<Product> getProducts() {
		List<Product> products = new ArrayList<Product>(productMap.values());
		return products;
	}

	@Override
	public Product addProduct(Product product) {
		productMap.put(product.getId(),product);
		return product;
	}
	

}
