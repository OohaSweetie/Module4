package com.cg.product.controller;

import java.util.List;

import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import com.cg.product.beans.Product;
import com.cg.product.service.ProductService;
import com.cg.product.service.ProductServiceImpl;

@Path("/products")
public class ProductController {
	ProductService service;
	public ProductController()
	{
		service=new ProductServiceImpl();
	}
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Product> getProducts() {
		List<Product> listOfProducts = service.getProducts();
		return listOfProducts;
	}
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public Product addProduct(@FormParam("id") int productId,
			@FormParam("name") String productName,
			@FormParam("price") int productPrice) {
		Product product=new Product();
		product.setId(productId);
		product.setName(productName);
		product.setPrice(productPrice);
		return service.addProduct(product);
	}
	

}
