package com.cg.webservice.dao;

import java.util.HashMap;

import javax.jws.WebService;

import com.cg.webservices.bean.Product;
import com.cg.webservices.staticdb.ProductDB;

@WebService(endpointInterface="com.cg.webservice.dao.ProductServer")
public class Productprice {
	
	static HashMap<String, Product> productNameMap = ProductDB.getProductNameMap();
	

	public  float getPrice(String productName)
	{
		Product product = productNameMap.get(productName);
		return product.getPrice();
	}
}
