package com.cg.webservices.service;

import java.util.List;


import com.cg.webservices.bean.Product;
import com.cg.webservices.dao.IProductDao;
import com.cg.webservices.dao.ProductDAOImpl;

public class ProductServiceImpl implements IProductService {
   IProductDao dao;
   public ProductServiceImpl() {
		dao = new ProductDAOImpl();
	}
   
	@Override
	public List<Product> getAllProducts() {
		return dao.getAllProducts();

	}

	@Override
	public Product getProduct(int id) {
		
		return dao.getProduct(id);
	}

	@Override
	public Product addProduct(Product product) {
		
		return dao.addProduct(product);
	}

	@Override
	public Product deleteProduct(int id) {
		
		return dao.deleteProduct(id);
		
	}

}
